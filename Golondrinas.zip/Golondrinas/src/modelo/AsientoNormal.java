/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author allan
 */
public class AsientoNormal extends Asiento {
public AsientoNormal() {
super("NORMAL");
}

@Override
public double calcularPrecio(double precioBase) {
return precioBase;
}
}